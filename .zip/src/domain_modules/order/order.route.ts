import { Router } from "express";
import { validation } from "../../middlewares/validation.middleware";
import * as orderSchemas from "./order.validation";
import * as orderController from "./order.controller";
const router = Router();

router.post("/createOrder",validation(orderSchemas.createOrderSchema), orderController.createOrder);
router.post("/",  validation(orderSchemas.createOrderSchema), orderController.createOrder);
router.get("/", orderController.viewOrders);
router.get("/:orderId", validation(orderSchemas.getOrderSchema), orderController.viewOrder);

export default router;
